1)
a. Ryan Jewik
b. 2404275
c. jewik@chapman.edu
d. CPSC392-01
e. HW3
2) 
a. N/A
3)
a. N/A

